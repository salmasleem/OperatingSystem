package milestone1;

public class userOutput {
	static int available;
	static String with;
	public userOutput(int available , String with) {
		userOutput.available=available;
		userOutput.with=with;
	}
	
}
