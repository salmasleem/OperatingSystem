package milestone1;

public enum status {
	Start, Ready, Blocked, Finished;
}
