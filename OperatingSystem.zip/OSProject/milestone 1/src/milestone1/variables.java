package milestone1;

public class variables {
	String name;
	String value;

public variables(String name, String value) {
	this.name = name;
	this.value = value;
}

public variables(String name) {
	this.name = name;
}

}
