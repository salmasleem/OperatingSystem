package milestone1;

public class userInput {
	static int available;
	static String with;
	public userInput(int available , String with) {
		userInput.available=available;
		userInput.with=with;
	}
	
	
}
