package milestone1;

public class file {
	static int available;
	static String with;
	public file(int available , String with) {
		file.available=available;
		file.with=with;
	}
	
}
